#include "RPN.hpp"
#include <string>


int main(int ac, char **av)
{
	try
	{
	
		s.stoi();
		
	}
	catch(...)
	{
		std::cout << exp.what() << '\n';
	}
	return 0;
}